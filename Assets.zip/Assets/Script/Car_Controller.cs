using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Car_Controller : MonoBehaviour
{
    public Rigidbody2D front, back;
    public float speed = 1300f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void FixedUpdate()
    {
        float horizontal = Input.GetAxis("Horizontal");
        front.AddTorque(- horizontal * speed * Time.deltaTime);
        back.AddTorque(- horizontal * speed * Time.deltaTime);
    }
}
