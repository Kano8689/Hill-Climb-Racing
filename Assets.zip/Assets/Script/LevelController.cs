using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.U2D;

public class LevelController : MonoBehaviour
{
    public SpriteShapeController SpriteShapecontroller;
    [Range(1f, 100f)] public int lvlSize = 100;
    [Range(1f, 50f)] public float Xsize = 2f;
    [Range(1f, 50f)] public float Ysize = 2f;
    [Range(0f, 1f)] public float curveAngle = 0.5f;
    public float noiseStep;
    public float bottom;

    public Vector3 lastPos;


    private void OnValidate()
    {
        SpriteShapecontroller.spline.Clear();

        for (int i = 0; i < lvlSize; i++)
        {
            lastPos = transform.position + new Vector3(i * Xsize, Mathf.PerlinNoise(0, i * noiseStep) * Ysize);
            SpriteShapecontroller.spline.InsertPointAt(i, lastPos);

            if (i != 0 && i != lvlSize - 1)
            {
                SpriteShapecontroller.spline.SetTangentMode(i, ShapeTangentMode.Continuous);
                SpriteShapecontroller.spline.SetLeftTangent(i, Vector3.left * Xsize* curveAngle);
                SpriteShapecontroller.spline.SetRightTangent(i, Vector3.right * Ysize * curveAngle);
            }
        }
        SpriteShapecontroller.spline.InsertPointAt(lvlSize, new Vector3(lastPos.x, transform.position.y - bottom));
        SpriteShapecontroller.spline.InsertPointAt(lvlSize + 1, new Vector3(transform.position.x, transform.position.y - bottom));

    }
}
